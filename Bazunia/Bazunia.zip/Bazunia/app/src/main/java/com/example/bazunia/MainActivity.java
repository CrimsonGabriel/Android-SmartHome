package com.example.bazunia;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.WebSocket;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private WebSocket webSocket;
    private DatabaseHelper dbHelper;
    private static final String SERVER_URL = "ws://10.0.2.2:3000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            new WebSocketServer();
        } catch (IOException e) {
            e.printStackTrace();
        }

        dbHelper = new DatabaseHelper(this);
        startWebSocket();

        Button btnView = findViewById(R.id.btnView);
        btnView.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DataActivity.class);
            startActivity(intent);
        });
    }

    private void startWebSocket() {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(SERVER_URL).build();
        webSocket = client.newWebSocket(request, new WebSocketClient(dbHelper));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webSocket != null) {
            webSocket.close(1000, "Zamknięcie aplikacji");
        }
    }
}
