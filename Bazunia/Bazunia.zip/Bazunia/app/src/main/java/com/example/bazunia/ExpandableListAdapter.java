package com.example.bazunia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

public class ExpandableListAdapter extends BaseExpandableListAdapter {
    private Context context;
    private List<String> listBramek;
    private HashMap<String, List<String>> czujnikiMap;

    public ExpandableListAdapter(Context context, List<String> listBramek, HashMap<String, List<String>> czujnikiMap) {
        this.context = context;
        this.listBramek = listBramek;
        this.czujnikiMap = czujnikiMap;
    }

    @Override
    public int getGroupCount() {
        return listBramek.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return czujnikiMap.get(listBramek.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return listBramek.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return czujnikiMap.get(listBramek.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String bramka = (String) getGroup(groupPosition);
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(android.R.layout.simple_expandable_list_item_1, null);
        }
        TextView textView = convertView.findViewById(android.R.id.text1);
        textView.setText("Bramka: " + bramka);
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        String czujnik = (String) getChild(groupPosition, childPosition);
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(android.R.layout.simple_list_item_1, null);
        }
        TextView textView = convertView.findViewById(android.R.id.text1);
        textView.setText("Czujnik: " + czujnik);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
