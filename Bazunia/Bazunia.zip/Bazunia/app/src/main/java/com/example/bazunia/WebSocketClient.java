package com.example.bazunia;

import android.os.Handler;
import android.util.Log;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.json.JSONException;
import org.json.JSONObject;

public class WebSocketClient extends WebSocketListener {

    private static final String TAG = "WebSocketClient";
    private DatabaseHelper dbHelper;
    private WebSocket webSocket;
    private Handler handler = new Handler();
    private static final int RECONNECT_DELAY = 5000;  // 5 sekund

    public WebSocketClient(DatabaseHelper dbHelper) {
        this.dbHelper = dbHelper;
    }

    @Override
    public void onOpen(WebSocket webSocket, Response response) {
        this.webSocket = webSocket;
        Log.d(TAG, "🟢 Połączono z WebSocket!");

        // Wysyłanie pingów co 10 sekund
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (webSocket != null) {
                    webSocket.send("PING");
                    handler.postDelayed(this, 10000);
                }
            }
        }, 10000);
    }

    @Override
    public void onMessage(WebSocket webSocket, String text) {
        Log.d(TAG, "📡 Otrzymano dane: " + text);

        try {
            // Parsowanie danych JSON
            JSONObject jsonData = new JSONObject(text);

            // Pobieranie danych z JSON
            int gateId = jsonData.getInt("gateway_id");
            int sensorId = jsonData.getInt("sensor_id");
            String type = jsonData.getString("type");
            String value = jsonData.getString("value");
            String timestamp = jsonData.getString("timestamp");

            // Logowanie otrzymanych danych
            Log.d(TAG, "🔍 Otrzymano dane: Gateway ID: " + gateId +
                    ", Sensor ID: " + sensorId +
                    ", Type: " + type +
                    ", Value: " + value +
                    ", Timestamp: " + timestamp);

            // Sprawdzenie poprawności danych (np. jeśli 'value' nie jest liczbą)
            if (isValidData(value)) {
                // Zapisanie danych w bazie SQLite
                boolean success = dbHelper.insertData(gateId, sensorId, type, value, timestamp);
                if (success) {
                    Log.d(TAG, "✅ Dane zapisane w SQLite");
                } else {
                    Log.e(TAG, "❌ Błąd zapisu do SQLite");
                }
            } else {
                Log.e(TAG, "❌ Błąd: Niepoprawna wartość czujnika");
            }
        } catch (JSONException e) {
            Log.e(TAG, "Błąd JSON: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "Błąd: " + e.getMessage());
        }
    }

    // Funkcja pomocnicza do sprawdzania poprawności danych (np. 'value' musi być liczbą)
    private boolean isValidData(String value) {
        try {
            Double.parseDouble(value);  // Próba przekonwertowania na liczbę
            return true;
        } catch (NumberFormatException e) {
            return false;  // Jeśli nie można przekonwertować, zwróć false
        }
    }


    @Override
    public void onClosing(WebSocket webSocket, int code, String reason) {
        Log.d(TAG, "🔴 Zamknięcie WebSocket: " + reason);
    }

    @Override
    public void onFailure(WebSocket webSocket, Throwable t, Response response) {
        Log.e(TAG, "⚠️ Błąd WebSocket: " + t.getMessage());

        // Próba ponownego połączenia po 5 sekundach
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "🔄 Próba ponownego połączenia...");
                // Tutaj możesz dodać kod do ponownego nawiązania połączenia
            }
        }, RECONNECT_DELAY);
    }

    public void sendMessage(String message) {
        if (webSocket != null) {
            webSocket.send(message);
        } else {
            Log.e(TAG, "⚠️ WebSocket nie jest połączony!");
        }
    }
}
