package com.example.bazunia;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class DataActivity extends AppCompatActivity {

    private ExpandableListView expandableListView;
    private List<String> listBramek;
    private HashMap<String, List<String>> czujnikiMap;
    private TextView textData;
    private Button btnBack;

    private Socket socket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        expandableListView = findViewById(R.id.expandableListView);
        textData = findViewById(R.id.textData);
        btnBack = findViewById(R.id.btnBack);

        listBramek = new ArrayList<>();
        czujnikiMap = new HashMap<>();

        setupSocket();

        expandableListView.setOnChildClickListener((parent, v, groupPosition, childPosition, id) -> {
            String gateId = listBramek.get(groupPosition);
            String sensorId = czujnikiMap.get(gateId).get(childPosition);
            requestSensorData(Integer.parseInt(gateId), Integer.parseInt(sensorId));
            return false;
        });

        btnBack.setOnClickListener(v -> finish());
    }

    private void setupSocket() {
        try {
            socket = IO.socket("http://your-server-ip:3000");
            socket.on(Socket.EVENT_CONNECT, args -> Log.d("Socket", "Połączono"));
            socket.on("updateData", onDataReceived);
            socket.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    private final Emitter.Listener onDataReceived = args -> runOnUiThread(() -> {
        try {
            JSONArray dataArray = (JSONArray) args[0];
            listBramek.clear();
            czujnikiMap.clear();

            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject obj = dataArray.getJSONObject(i);
                String gateId = obj.getString("gateId");
                String sensorId = obj.getString("sensorId");

                if (!czujnikiMap.containsKey(gateId)) {
                    czujnikiMap.put(gateId, new ArrayList<>());
                    listBramek.add(gateId);
                }

                if (!czujnikiMap.get(gateId).contains(sensorId)) {
                    czujnikiMap.get(gateId).add(sensorId);
                }
            }

            ExpandableListAdapter adapter = new ExpandableListAdapter(DataActivity.this, listBramek, czujnikiMap);
            expandableListView.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    });

    private void requestSensorData(int gateId, int sensorId) {
        socket.emit("getSensorData", gateId, sensorId);
        socket.on("sensorData", args -> runOnUiThread(() -> {
            try {
                JSONObject data = (JSONObject) args[0];
                String displayData = "Typ: " + data.getString("type") + "\n"
                        + "Wartość: " + data.getString("value") + "\n"
                        + "Timestamp: " + data.getString("timestamp");

                textData.setText(displayData);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        socket.disconnect();
    }
}
