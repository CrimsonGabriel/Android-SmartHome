package com.example.bazunia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "sensor_data.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "sensors";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_GATE_ID = "gate_id";
    private static final String COLUMN_SENSOR_ID = "sensor_id";
    private static final String COLUMN_TYPE = "type";
    private static final String COLUMN_VALUE = "value";
    private static final String COLUMN_TIMESTAMP = "timestamp";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_GATE_ID + " INTEGER, " +
                COLUMN_SENSOR_ID + " INTEGER, " +
                COLUMN_TYPE + " TEXT, " +
                COLUMN_VALUE + " TEXT, " +
                COLUMN_TIMESTAMP + " TEXT);";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(int gateId, int sensorId, String type, String value, String timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_GATE_ID, gateId);
        contentValues.put(COLUMN_SENSOR_ID, sensorId);
        contentValues.put(COLUMN_TYPE, type);
        contentValues.put(COLUMN_VALUE, value);
        contentValues.put(COLUMN_TIMESTAMP, timestamp);

        try {
            long result = db.insert(TABLE_NAME, null, contentValues);
            db.close();
            if (result == -1) {
                Log.e("DB_ERROR", "Nie udało się zapisać danych");
                return false;
            } else {
                Log.d("DB_SUCCESS", "Dane zapisane poprawnie");
                return true;
            }
        } catch (SQLException e) {
            Log.e("DB_EXCEPTION", "Błąd SQL: " + e.getMessage());
            return false;
        }
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
}
