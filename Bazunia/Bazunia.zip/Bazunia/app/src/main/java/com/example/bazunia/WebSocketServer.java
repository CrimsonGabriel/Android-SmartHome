package com.example.bazunia;


import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.NanoWSD;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class WebSocketServer extends NanoWSD {

    private static final int PORT = 3000;
    private static final Set<MyWebSocket> clients = new HashSet<>();

    public WebSocketServer() throws IOException {
        super(PORT);  // Usunięcie "0.0.0.0", wystarczy sam port
        try {
            System.out.println("🔄 Uruchamiam serwer WebSocket...");
            start(NanoHTTPD.SOCKET_READ_TIMEOUT * 10, false);  // Większy timeout
            System.out.println("✅ Serwer działa na ws://0.0.0.0:" + PORT);
        } catch (IOException e) {
            System.err.println("❌ Błąd uruchamiania serwera: " + e.getMessage());
        }
    }

    @Override
    protected WebSocket openWebSocket(IHTTPSession handshake) {
        MyWebSocket socket = new MyWebSocket(handshake);
        clients.add(socket);
        System.out.println("🔗 Nowe połączenie WebSocket! Liczba klientów: " + clients.size());
        return socket;
    }

    private static class MyWebSocket extends WebSocket {
        public MyWebSocket(IHTTPSession handshake) {
            super(handshake);
        }

        @Override
        protected void onOpen() {
            System.out.println("🟢 WebSocket połączony!");
            try {
                send("👋 Witaj w serwerze WebSocket!");
            } catch (IOException e) {
                System.err.println("⚠️ Błąd przy wysyłaniu powitalnej wiadomości: " + e.getMessage());
            }
        }

        @Override
        protected void onClose(WebSocketFrame.CloseCode code, String reason, boolean initiatedByRemote) {
            clients.remove(this);
            System.out.println("❌ Połączenie WebSocket zamknięte: " + reason + " (pozostało " + clients.size() + " klientów)");
        }

        @Override
        protected void onMessage(WebSocketFrame message) {
            String receivedMessage = message.getTextPayload();
            System.out.println("📩 Otrzymano: " + receivedMessage);

            // Odesłanie wiadomości do wszystkich klientów
            for (MyWebSocket client : new HashSet<>(clients)) {
                try {
                    client.send("📡 Echo: " + receivedMessage);
                } catch (IOException e) {
                    System.err.println("⚠️ Błąd wysyłania wiadomości: " + e.getMessage());
                }
            }
        }

        @Override
        protected void onPong(WebSocketFrame pong) {}

        @Override
        protected void onException(IOException e) {
            System.err.println("⚠️ Błąd WebSocket: " + e.getMessage());
        }
    }
}
